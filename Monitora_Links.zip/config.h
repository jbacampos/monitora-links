#ifndef CONFIG_H
#define CONFIG_H

#include <Arduino.h>

/*********************************************************************
 * VERSÃO
 *********************************************************************/

#define FW_VERSION "0.9"
#define MAGIC_NUMBER 0x56434D4F
#define STATE_VERSION 5

/*********************************************************************
 * MODOS
 *********************************************************************/

#define DEV_MODE true // 1 PARA TESTE, 0 PARA PRODUÇÃO
#define EM_POA true   // Alterna entre as redes wifi de diferentes locais

#define ENABLE_SLEEP                                                           \
   false // Não usado por ora. Serve apenas para economizar energia, caso a
         // alimentação seja por bateria

/*********************************************************************
 * OPERAÇÃO
 *********************************************************************/

#define CICLO_MINUTOS 5

/*********************************************************************
 * LED
 *********************************************************************/

constexpr uint8_t LED_RED_PIN = D5;
constexpr uint8_t LED_GREEN_PIN = D6;
constexpr uint8_t LED_BLUE_PIN = D7;

enum ledMode : uint8_t { LED_MODE_OFF = 0, LED_MODE_ON, LED_MODE_QUIET };

/*********************************************************************
 * NOTIFICAÇÕES
 *********************************************************************/

#define NOTIFICATIONS_ENABLED_DEFAULT true
#define QUIET_HOURS_ENABLED_DEFAULT true
#define QUIET_HOURS_START_DEFAULT (22 * 60)
#define QUIET_HOURS_END_DEFAULT (7 * 60)
// #define SUMMARY_ENABLED_DEFAULT        true
// #define SUMMARY_TIME_DEFAULT           (8 * 60)
// #define SUMMARY_WINDOW_MINUTES         10
#define LED_MODE_DEFAULT LED_MODE_QUIET

/*********************************************************************
 * ESTATÍSTICAS
 *********************************************************************/

#define MAX_EVENTS 256

/*********************************************************************
 * ARQUIVOS
 *********************************************************************/

#define FILE_STATE "/state.bin"
#define FILE_EVENTS "/events.bin"
#define FILE_QUEUE "/queue.bin"

/******************************************************************************
 * NTP
 ******************************************************************************/

#define NTP_SERVER_1 "pool.ntp.org"
#define NTP_SERVER_2 "a.st1.ntp.br"
#define NTP_SERVER_3 "time.google.com"

#define GMT_OFFSET_SEC (-3 * 3600)
#define DAYLIGHT_OFFSET_SEC 0
#define SECONDS_PER_DAY 86400UL

/******************************************************************************
 * TELEGRAM
 ******************************************************************************/

#define TELEGRAM_BOT_TOKEN "8002312967:AAEWpACMvHThfw6UiNnSTFRIYZ0-jaiKWJ8"
#define TELEGRAM_CHAT_ID "-5398580561"
#define TELEGRAM_HOST "api.telegram.org"
#define TELEGRAM_PORT 443
#define MAX_PENDING_NOTIFICATIONS 4

/*********************************************************************
 * MONITORAMENTO
 *********************************************************************/

constexpr uint8_t LINK_TEST_RETRIES = 3;
constexpr uint16_t RETRY_DELAY_MS = 300;
constexpr uint32_t WIFI_CONNECT_TIMEOUT_MS = 8000;

/*********************************************************************
 * DEBUG
 *********************************************************************/

#if DEV_MODE
#define DBG(...) Serial.printf(__VA_ARGS__)
#else
#define DBG(...)
#endif

#endif