#ifndef TYPES_H
#define TYPES_H

//=============================================================================
// types.h
//
// Tipos, constantes e estruturas compartilhados por todo o projeto.
//
// Este módulo define o modelo de dados utilizado pelo Monitor Links,
// centralizando:
//
//   • Configuração dos links monitorados.
//   • Enumerações.
//   • Estruturas persistentes.
//   • Estruturas auxiliares.
//   • Funções de conversão.
//
//=============================================================================

#include "config.h"

#include <Arduino.h>
#include <time.h>

//=============================================================================
// Tipos básicos
//=============================================================================

typedef uint8_t LinkId;

//=============================================================================
// Configuração dos links monitorados
//=============================================================================

typedef struct {
   const char *nome;
   const char *ssid;
   const char *senha;
   const char *emojiOnline;
   const char *emojiOffline;
} LinkConfig;

// Para alterar os links monitorados,
// basta modificar NUM_LINKS e o vetor LINKS[] abaixo definidos.

#if EM_POA
constexpr uint8_t NUM_LINKS = 3;
constexpr LinkConfig LINKS[NUM_LINKS] = {
    {"REDE MESH", "AP_903", "OliverHuno2016!", "🟢", "🔴"},
    {"LINK CLARO", "Bavi_NET_2G", "COliverHuno2016", "🟢", "🔴"},
    {"LINK VIVO", "Bavi_Vivo_2G", "VOliverHuno2016", "🟢", "🔴"},
};
#else
constexpr uint8_t NUM_LINKS = 2;
constexpr LinkConfig LINKS[NUM_LINKS] = {
    {"SÍTIO", "Sitio", "OliverHuno2016!", "🟩", "🟥"},
    {"IoT", "DispIoT", "IOkorma098", "🟢", "🔴"}};
#endif

//=============================================================================
// Enumerações
//=============================================================================

typedef enum : uint8_t {
   LINK_ONLINE,
   LINK_WIFI_FAIL,
   LINK_INTERNET_FAIL
} LinkStatus;

typedef enum : uint8_t {
   BOOT_POWERON,
   BOOT_DEEPSLEEP,
   BOOT_EXTERNAL,
   BOOT_WATCHDOG,
   BOOT_UNKNOWN
} BootReason;

enum NotificationType : uint8_t { NOTIFY_DOWN, NOTIFY_UP };

//=============================================================================
// Estruturas
//=============================================================================

// Estado persistente de um link monitorado.
typedef struct {
   LinkStatus status;
   bool downNotificationSent;
   uint32_t eventoAtual;

   time_t ultimaMudanca;
   LinkStatus motivoFalha;
   time_t inicioFalha;

   int16_t ultimoRSSI;

   uint32_t totalFalhas;
   uint32_t totalTestes;
   uint32_t testesFalhos;

   time_t ultimoTeste;
   uint32_t tempoFalhaAcumulado;

} LinkState;

// Evento registrado no histórico.
typedef struct {
   uint32_t id;

   LinkStatus motivo;

   time_t inicio;
   time_t fim;
   uint32_t duracaoSeg;

   int16_t rssi;
   LinkId link;

   bool enviadoTelegram;
} Evento;

// Notificação pendente de envio.
typedef struct {
   NotificationType tipo;

   LinkStatus motivo;
   uint32_t evento;

   time_t inicio;
   time_t fim;
   uint32_t duracao;

   int16_t rssi;
   LinkId link;

   bool pending;
} PendingNotification;

// Estatísticas calculadas para um link.
typedef struct {
   uint32_t downtime24h;
   uint32_t downtime7d;
   uint32_t downtime30d;
   uint32_t downtime180d;
   uint32_t totalDowntime;
   uint32_t eventCount;
} LinkStatistics;

typedef struct {
   bool enabled;
   bool quietEnabled;
   bool summaryEnabled;
   uint8_t ledMode;
   uint16_t quietStart;
   uint16_t quietEnd;
   // uint16_t summaryTime;
   // uint16_t summaryDay;

} NotificationSettings;

// Estado persistente do sistema.
typedef struct {
   uint32_t magic;
   uint16_t version;

   uint16_t primeiroEvento;
   uint16_t numeroEventos;

   uint32_t bootCount;
   uint32_t cicloCount;
   uint32_t watchdogCount;

   time_t ultimoHorarioValido;
   uint32_t ciclosSemNTP;

   Evento eventos[MAX_EVENTS];
   uint32_t proximoEvento;

   PendingNotification pendingNotifications[MAX_PENDING_NOTIFICATIONS];

   LinkState links[NUM_LINKS];

   uint32_t telegramUpdateId;

   NotificationSettings notification;

} PersistState;

//=============================================================================
// Interface pública
//=============================================================================

extern PersistState gState;

const char *linkStatusName(LinkStatus status);
const char *linkStatusDescription(LinkStatus status);

#endif