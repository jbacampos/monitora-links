#include "storage.h"

#include "config.h"

//=============================================================================
// Estado global
//=============================================================================

PersistState gState;

//=============================================================================
// Sistema de arquivos
//=============================================================================

bool initFS() { return LittleFS.begin(); }

//=============================================================================
// Persistência
//=============================================================================

bool loadState(PersistState *st) {
   File f = LittleFS.open("/state.bin", "r");

   if (!f) {
      DBG("state.bin inexistente.\n");
      return false;
   }

   size_t lidos = f.read((uint8_t *)st, sizeof(PersistState));

   if (f.size() != sizeof(PersistState)) {
      DBG("Tamanho de state.bin incompatível\n");
      DBG("Arquivo : %u bytes\n", (unsigned)f.size());
      DBG("Esperado: %u bytes\n", sizeof(PersistState));

      f.close();
      return false;
   }

   if (st->version != STATE_VERSION) {
      DBG("STATE_VERSION diferente\n");
      DBG("Gravado : %u\n", st->version);
      DBG("Esperado: %u\n", STATE_VERSION);
      return false;
   }

   f.close();

   return (lidos == sizeof(PersistState)) && (st->magic == MAGIC_NUMBER);
}

bool saveState(PersistState *st) {
   File f = LittleFS.open("/state.bin", "w");

   if (!f) {
      DBG("Não foi possível gravar /state.bin\n");
      return false;
   }

   size_t gravados = f.write((uint8_t *)st, sizeof(PersistState));

   f.close();

   return gravados == sizeof(PersistState);
}

//=============================================================================
// Administração
//=============================================================================

// Inicializa um novo estado persistente e grava state.bin.
void createDefaultState() {
   memset(&gState, 0, sizeof(gState));

   gState.magic = MAGIC_NUMBER;
   gState.version = STATE_VERSION;

   gState.proximoEvento = 1;

   for (uint8_t i = 0; i < NUM_LINKS; i++) {
      gState.links[i].status = LINK_ONLINE;
   }

   gState.notification.enabled = NOTIFICATIONS_ENABLED_DEFAULT;
   gState.notification.quietEnabled = QUIET_HOURS_ENABLED_DEFAULT;
   gState.notification.quietStart = QUIET_HOURS_START_DEFAULT;
   gState.notification.quietEnd = QUIET_HOURS_END_DEFAULT;
   // gState.notification.summaryEnabled = SUMMARY_ENABLED_DEFAULT;
   // gState.notification.summaryTime    = SUMMARY_TIME_DEFAULT;
   // gState.notification.summaryDay     = 0xFFFF;
   gState.notification.ledMode = LED_MODE_DEFAULT;

   DBG("Criando novo state.bin\n");
   DBG("gState.version: %u\n", gState.version);

   saveState(&gState);
}

void resetState() {
   LittleFS.remove("/state.bin");
   createDefaultState();
}