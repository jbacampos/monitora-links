#include "stats.h"

#include "config.h"
#include "eventlog.h"
#include "ntp.h"

//=============================================================================
// Estatísticas
//=============================================================================

uint32_t getDowntime(LinkId link, uint16_t dias) {

   if (!clockIsValid())
      return 0;

   time_t limite = now() - (time_t)dias * SECONDS_PER_DAY;
   uint32_t total = 0;
   uint16_t totalEventos = getEventCount();

   for (uint16_t i = 0; i < totalEventos; i++) {
      const Evento *ev = getEvent(i);
      if (ev->link != link)
         continue;
      if (ev->fim < limite)
         continue;
      total += ev->duracaoSeg;
   }
   return total;
}

uint16_t getFailureCount(LinkId link, uint16_t dias) {

   if (!clockIsValid())
      return 0;

   time_t limite = now() - (time_t)dias * SECONDS_PER_DAY;
   uint16_t total = 0;

   uint16_t totalEventos = getEventCount();

   for (uint16_t i = 0; i < totalEventos; i++) {
      const Evento *ev = getEvent(i);
      if (ev->link != link)
         continue;
      if (ev->fim < limite)
         continue;
      total++;
   }

   return total;
}

uint32_t getLongestFailure(LinkId link, uint16_t dias) {

   if (!clockIsValid())
      return 0;

   time_t limite = now() - (time_t)dias * SECONDS_PER_DAY;
   uint32_t maior = 0;

   uint16_t totalEventos = getEventCount();

   for (uint16_t i = 0; i < totalEventos; i++) {
      const Evento *ev = getEvent(i);
      if (ev->link != link)
         continue;
      if (ev->inicio == 0)
         continue;
      if (ev->inicio < limite)
         continue;
      if (ev->duracaoSeg > maior)
         maior = ev->duracaoSeg;
   }

   return maior;
}

uint32_t getAverageFailure(LinkId link, uint16_t dias) {

   if (!clockIsValid())
      return 0;

   time_t limite = now() - (time_t)dias * SECONDS_PER_DAY;
   uint32_t total_falhas = 0, total_tempo = 0;

   uint16_t totalEventos = getEventCount();

   for (uint16_t i = 0; i < totalEventos; i++) {
      const Evento *ev = getEvent(i);
      if (ev->link != link)
         continue;
      if (ev->inicio == 0)
         continue;
      if (ev->inicio < limite)
         continue;
      total_falhas++;
      total_tempo += ev->duracaoSeg;
   }
   return (total_falhas == 0) ? 0 : total_tempo / total_falhas;
}

float getUptime(LinkId link, uint16_t dias) {
   uint32_t tempoPeriodo = dias * SECONDS_PER_DAY;
   uint32_t tempoFora = getDowntime(link, dias);

   return 100.0f * (tempoPeriodo - tempoFora) / tempoPeriodo;
}
