#ifndef LED_H
#define LED_H

#include <Arduino.h>

#include "notify.h"
#include "types.h"

enum LedStatus : uint8_t { LED_ALL_UP, LED_PARTIAL_DOWN, LED_ALL_DOWN };

enum LedColor : uint8_t {
   LED_BLANK,
   LED_RED,
   LED_GREEN,
   LED_BLUE,
   LED_YELLOW,
   LED_MAGENTA,
   LED_CYAN,
   LED_WHITE
};

void setColor(LedColor color);

bool ledsEnabled();

void ledsInit();

void ledsBeginCycle();

void ledsEndCycle(LedStatus status);

void ledsUpdate();

#endif