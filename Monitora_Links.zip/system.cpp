#include "system.h"

#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <user_interface.h>

#include "config.h"
#include "storage.h"
#include "types.h"
#include <LittleFS.h>

//=============================================================================
// Inicialização
//=============================================================================

void initSystem() {
   WiFi.persistent(false);
   WiFi.setAutoConnect(false);
   WiFi.setAutoReconnect(false);

   if (!initFS()) {
      Serial.println("ERRO LITTLEFS");

      while (true)
         delay(1000);
   }

   if (!loadState(&gState)) {
      createDefaultState();
   }

   BootReason br = getBootReason();

   switch (br) {
   case BOOT_DEEPSLEEP:
      gState.cicloCount++;
      break;

   case BOOT_WATCHDOG:
      gState.bootCount++;
      gState.watchdogCount++;
      break;

   default:
      gState.bootCount++;
      break;
   }

   saveState(&gState);
}

//=============================================================================
// Diagnóstico
//=============================================================================

BootReason getBootReason() {
   rst_info *rst = ESP.getResetInfoPtr();

   switch (rst->reason) {
   case REASON_DEFAULT_RST:
      return BOOT_POWERON;

   case REASON_EXT_SYS_RST:
      return BOOT_EXTERNAL;

   case REASON_WDT_RST:
   case REASON_SOFT_WDT_RST:
      return BOOT_WATCHDOG;

   case REASON_DEEP_SLEEP_AWAKE:
      return BOOT_DEEPSLEEP;

   default:
      return BOOT_UNKNOWN;
   }
}

//=============================================================================
// Energia
//=============================================================================

void goToSleep() {
#if ENABLE_SLEEP
   DBG("Entrando em Deep Sleep\n");
   ESP.deepSleep((uint64_t)CICLO_MINUTOS * 60ULL * 1000000ULL);
#endif
}