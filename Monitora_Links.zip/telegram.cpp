#include "telegram.h"

#include <Arduino.h>
#include <ESP8266HTTPClient.h>
#include <ESP8266WiFi.h>
#include <WiFiClientSecure.h>

#include "config.h"
#include "network.h"
#include "notify.h"
#include "reports.h"
#include "storage.h"

//=============================================================================
// Tipos internos
//=============================================================================

typedef String (*CommandHandler)(const String &args);

typedef struct {
   const char *comando;
   CommandHandler handler;
} TelegramCommand;

//=============================================================================
// Protótipos privados
//=============================================================================

static bool telegramParseUpdate(const String &json, TelegramUpdate *upd);
bool parseUintArg(const String &args, uint16_t &value, uint16_t defaultValue,
                  uint16_t minValue, uint16_t maxValue);
static bool isUnsignedInteger(const String &s);

//=============================================================================
// Comandos
//=============================================================================

static const TelegramCommand COMMANDS[] = {
    {"/h", cmdHelp},        {"/help", cmdHelp},    {"/s", cmdStatus},
    {"/status", cmdStatus}, {"/e", cmdStats},      {"/stats", cmdStats},
    {"/l", cmdLog},         {"/log", cmdLog},      {"/n", cmdNotify},
    {"/notify", cmdNotify}, {"/q", cmdQuiet},      {"/quiet", cmdQuiet},
    {"/led", cmdLed},       {"/reboot", cmdReboot}};

constexpr uint8_t NUM_COMMANDS = sizeof(COMMANDS) / sizeof(COMMANDS[0]);

String telegramProcessCommand(const String &text) {
   String comando = text;
   String args;
   int p = text.indexOf(' ');

   if (p >= 0) {
      comando = text.substring(0, p);
      args = text.substring(p + 1);
      args.trim();
   }

   for (uint8_t i = 0; i < NUM_COMMANDS; i++) {
      if (comando.equalsIgnoreCase(COMMANDS[i].comando))
         return COMMANDS[i].handler(args);
   }
   return "Comando desconhecido.\nDigite /help.";
}

String cmdHelp(const String &) {

   String msg = "==========================\n";
   msg += "Monitora Links - Comandos\n";
   msg += "==========================\n";
   msg += "/status | <b>/s</b>\nStatus atual do sistema\n\n";
   msg += "/stats | <b>/e</b>   [dias]\nEstatísticas\n\n";
   msg += "/log | <b>/l</b>   [n]\nÚltimos eventos\n\n";
   msg += "/notify | <b>/n</b>\nMostra a configuração das notificações\n\n";
   msg += "/notify | <b>/n</b>   on|off\nAtiva/desativa notificações\n\n";
   msg += "/quiet | <b>/q</b>\nConfiguração do período quieto\n\n";
   msg += "/quiet | <b>/q</b>   on|off\nAtiva/desativa período quieto\n\n";
   msg += "/quiet | <b>/q</b>   hh:mm hh:mm\nDefine período quieto\n\n";
   msg += "<b>/led</b>\nConfiguração do led\n\n";
   msg += "<b>/led</b>   on|off|q[uiet]\nAtiva/desativa/desativa no período "
          "quieto\n\n";
   msg += "<b>/reboot</b>\nReinicia o monitor\n\n";

   return msg;
}

String cmdStatus(const String &) {
   String msg = buildStatus();
   msg += buildSystemSummary();
   return msg;
}

String cmdStats(const String &args) {
   uint16_t dias;
   if (!parseUintArg(args, dias, 5, 1, 180)) {
      return "Uso:\n/stats [dias]\ndias = 1-180";
   }
   return buildStatistics(dias);
}

String cmdLog(const String &args) {
   uint16_t eventos;
   if (!parseUintArg(args, eventos, 10, 1, 180)) {
      return "Uso:/Log [eventos]\neventos = 1-180";
   }
   return buildLog(eventos);
}

String cmdNotify(const String &args) {

   String msg, arg1, arg2, arg3;
   int8_t totArgs;
   uint16_t min1, min2;

   totArgs = splitArgs(args, arg1, arg2, arg3);

   if (totArgs == 0) {
      msg = buildInfoNotif();

   } else if (totArgs == 1 && arg1.equalsIgnoreCase("on")) {
      gState.notification.enabled = true;
      saveState(&gState);
      msg = "\n🔔 Notificações ATIVADAS";

   } else if (totArgs == 1 && arg1.equalsIgnoreCase("off")) {
      gState.notification.enabled = false;
      saveState(&gState);
      msg = "\n🔕 Notificações DESATIVADAS";

   } else {
      msg = "⚠️ Comando inválido.\nUso:\n"
            "/notify|/n\n"
            "/notify|/n on|off\n";
   }
   return msg;
}

String cmdQuiet(const String &args) {

   String msg, arg1, arg2, arg3;
   int8_t totArgs;
   uint16_t min1, min2;

   totArgs = splitArgs(args, arg1, arg2, arg3);

   if (totArgs == 0) {
      msg += "\nPeríodo quieto:\n";
      msg += (gState.notification.quietEnabled) ? "ATIVO - " : "INATIVO - ";
      msg += formatTime(gState.notification.quietStart);
      msg += " - ";
      msg += formatTime(gState.notification.quietEnd);
      // msg += "\n\nResumo do período quieto:\n";
      // msg += (gState.notification.summaryEnabled) ? "ATIVO" : "INATIVO";

   } else if (totArgs == 1 && arg1.equalsIgnoreCase("on")) {
      gState.notification.quietEnabled = true;
      saveState(&gState);
      msg = "\n🔔 Período quieto ATIVADO\n" +
            formatTime(gState.notification.quietStart) + " - " +
            formatTime(gState.notification.quietEnd);

   } else if (totArgs == 1 && arg1.equalsIgnoreCase("off")) {
      gState.notification.quietEnabled = false;
      saveState(&gState);
      msg = "\n🔕 Período quieto DESATIVADO";

   } else if (totArgs == 2 && parseTime(arg1, &min1) &&
              parseTime(arg2, &min2)) {
      if (min1 == min2) {
         msg = "\n⚠️ Horários inicial e final devem ser diferentes";
      } else {
         gState.notification.quietStart = min1;
         gState.notification.quietEnd = min2;
         gState.notification.quietEnabled = true;
         saveState(&gState);
         msg = "🔔 Período quieto:\nREDEFINIDO e ATIVADO\n" +
               formatTime(gState.notification.quietStart) + " - " +
               formatTime(gState.notification.quietEnd);
      }

   } else {
      msg = "⚠️ Comando inválido.\nUso:\n"
            "/quiet|/q\n"
            "/quiet|/q on|off\n"
            "/quiet|/q hh:mm hh:mm\n";
   }
   return msg;
}

String cmdLed(const String &args) {

   String msg, arg1, arg2, arg3;
   int8_t totArgs;

   totArgs = splitArgs(args, arg1, arg2, arg3);

   if (totArgs == 0) {
      msg = buildInfoLed();

   } else if (totArgs == 1 && arg1.equalsIgnoreCase("off")) {
      gState.notification.ledMode = LED_MODE_OFF;
      saveState(&gState);
      msg = "\nAtividade dos leds:\n⚪ DESATIVADA";

   } else if (totArgs == 1 && arg1.equalsIgnoreCase("on")) {
      gState.notification.ledMode = LED_MODE_ON;
      saveState(&gState);
      msg = "\nAtividade dos leds:\n🔵 ATIVADA";

   } else if (totArgs == 1 &&
              (arg1.equalsIgnoreCase("q") || arg1.equalsIgnoreCase("quiet"))) {
      gState.notification.ledMode = LED_MODE_QUIET;
      saveState(&gState);
      msg = "\nAtividade dos leds:\n⚪🔵 DESATIVADA no período quieto";

   } else {
      msg = "⚠️ Comando inválido.\nUso:\n\n"
            "/leds\n"
            "/leds on|off|q[uiet]";
   }

   return msg;
}

String cmdReboot(const String &) {
   // telegramSendMessage("♻️ Reiniciando o monitor...");
   telegramSendMessage("🔄 Reiniciando o monitor...");
   delay(1000);
   ESP.restart();
   return "";
}

//=============================================================================
// Inicialização
//=============================================================================

bool telegramInit() { return true; }

//=============================================================================
// Comunicação HTTP
//=============================================================================

bool telegramSendMessage(const String &text) {
   WiFiClientSecure client;
   client.setInsecure();
   HTTPClient http;

   String url = "https://" + String(TELEGRAM_HOST) + "/bot" +
                TELEGRAM_BOT_TOKEN + "/sendMessage";
   if (!http.begin(client, url)) {
      DBG("Telegram: erro em http.begin()\n");
      return false;
   }

   http.addHeader("Content-Type", "application/x-www-form-urlencoded");

   String body = "chat_id=" + String(TELEGRAM_CHAT_ID) + "&parse_mode=HTML" +
                 "&text=" + text;

   int code = http.POST(body);

   if (code == HTTP_CODE_OK) {
      DBG("Telegram: mensagem enviada\n");
   } else {
      DBG("Telegram... %s (%d)\n", http.errorToString(code).c_str(), code);
   }

   http.end();

   return (code == HTTP_CODE_OK);
}

bool telegramGetUpdates(TelegramUpdate *upd) {
   WiFiClientSecure client;
   client.setInsecure();
   HTTPClient http;

   String url =
       "https://" + String(TELEGRAM_HOST) + "/bot" + TELEGRAM_BOT_TOKEN +
       "/getUpdates?offset=" + String(gState.telegramUpdateId + 1) + "&limit=1";

   // DBG("%s\n", url.c_str());

   if (!http.begin(client, url)) {
      DBG("Telegram: erro em http.begin()\n");
      return false;
   }

   int code = http.GET();
   bool ok = false;

   if (code == HTTP_CODE_OK) {
      String json = http.getString();
      ok = telegramParseUpdate(json, upd);
   } else {
      DBG("Telegram... %s (%d)\n", http.errorToString(code).c_str(), code);
   }

   http.end();

   return ok;
}

//=============================================================================
// r
//=============================================================================

static bool telegramParseUpdate(const String &json, TelegramUpdate *upd) {
   int p, q;
   // update_id
   p = json.indexOf("\"update_id\":");
   if (p < 0)
      return false;

   p += 12;
   upd->updateId = strtoul(json.c_str() + p, nullptr, 10);

   // chat.id
   p = json.indexOf("\"chat\":");
   if (p < 0)
      return false;

   p = json.indexOf("\"id\":", p);
   if (p < 0)
      return false;

   p += 5;
   q = p;
   if (json[q] == '-')
      q++;

   while (q < json.length() && isDigit(json[q]))
      q++;

   upd->chatId = json.substring(p, q);

   // text
   p = json.indexOf("\"text\":\"");
   if (p < 0) {
      upd->text = "";
      return true; // Update válido, mas sem mensagem de texto.
   }

   p += 8;
   q = json.indexOf('"', p);
   if (q < 0)
      return false;

   upd->text = json.substring(p, q);

   return true;
}

uint8_t splitArgs(const String &args, String &arg1, String &arg2,
                  String &arg3) {

   if (args.isEmpty())
      return 0;

   int totArgs = 1;
   int p1 = args.indexOf(' ');

   if (p1 < 0) {
      arg1 = args;
   } else {
      arg1 = args.substring(0, p1);
      int p2 = args.indexOf(' ', p1 + 1);
      if (p2 < 0) {
         arg2 = args.substring(p1 + 1);
         totArgs = 2;
      } else {
         arg2 = args.substring(p1 + 1, p2);
         arg3 = args.substring(p2 + 1);
         totArgs = 3;
      }
   }

   return totArgs;
}

bool parseUintArg(const String &args, uint16_t &value, uint16_t defaultValue,
                  uint16_t minValue, uint16_t maxValue) {

   if (args.isEmpty()) {
      value = defaultValue;
   } else {
      if (!isUnsignedInteger(args)) {
         return false;
      }
      value = args.toInt();
      if (value < minValue || value > maxValue)
         value = defaultValue;
   }

   return true;
}

bool parseTime(const String &str, uint16_t *minutes) {
   if (str.length() != 5)
      return false;
   if (str.charAt(2) != ':')
      return false;
   if (!isdigit(str.charAt(0)) || !isdigit(str.charAt(1)) ||
       !isdigit(str.charAt(3)) || !isdigit(str.charAt(4)))
      return false;

   uint8_t h = (str.charAt(0) - '0') * 10 + str.charAt(1) - '0';

   uint8_t m = (str.charAt(3) - '0') * 10 + str.charAt(4) - '0';

   if (h > 23 || m > 59)
      return false;

   *minutes = h * 60 + m;

   return true;
}

static bool isUnsignedInteger(const String &s) {

   for (uint16_t i = 0; i < s.length(); i++) {
      if (!isDigit(s[i]))
         return false;
   }

   return true;
}
//=============================================================================
// Autorização
//=============================================================================

bool isAuthorizedChat(const String &chatId) {
   return chatId == String(TELEGRAM_CHAT_ID);
}
