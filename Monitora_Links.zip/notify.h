#ifndef NOTIFY_H
#define NOTIFY_H

#include <time.h>

#include "types.h"

//=============================================================================
// Fila de notificações
//=============================================================================

void queueNotification(const PendingNotification &n);

bool hasPendingNotifications();
uint8_t getPendingNotificationCount();
void sendPendingNotifications();

//=============================================================================
// Política de notificações
//=============================================================================

String formatTime(uint16_t min);

bool quietHoursEnabled();

bool inQuietHours();

bool shouldSendNotification();

bool failureStartedDuringQuiet(time_t inicio);

void checkNotificationPolicy();

// bool shouldSendSummary();
// String buildQuietSummary();

#endif