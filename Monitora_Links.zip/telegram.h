#ifndef TELEGRAM_H
#define TELEGRAM_H

#include <Arduino.h>

//=============================================================================
// Estruturas
//=============================================================================

typedef struct {
   uint32_t updateId;
   String chatId;
   String text;
} TelegramUpdate;

extern TelegramUpdate gUpdate;

//=============================================================================
// Inicialização
//=============================================================================

bool telegramInit();

//=============================================================================
// Comunicação
//=============================================================================

bool telegramSendMessage(const String &text);

bool telegramGetUpdates(TelegramUpdate *upd);

//=============================================================================
// Processamento
//=============================================================================

String telegramProcessCommand(const String &text);

static String cmdHelp(const String &args);
static String cmdStatus(const String &args);
static String cmdStats(const String &args);
static String cmdLog(const String &args);
static String cmdNotify(const String &args);
static String cmdQuiet(const String &args);
static String cmdReboot(const String &args);
static String cmdLed(const String &args);

uint8_t splitArgs(const String &args, String &arg1, String &arg2, String &arg3);
bool parseTime(const String &str, uint16_t *minutes);

//=============================================================================
// Autorização
//=============================================================================

bool isAuthorizedChat(const String &chatId);

#endif