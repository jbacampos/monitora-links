#include "config.h"
#include "eventlog.h"
#include "events.h"
#include "led.h"
#include "monitor.h"
#include "network.h"
#include "notify.h"
#include "ntp.h"
#include "reports.h"
#include "stats.h"
#include "storage.h"
#include "system.h"
#include "telegram.h"
#include "types.h"

constexpr uint8_t MAX_UPDATES_PER_CYCLE = 10;

void setup() {

   Serial.begin(115200);
   delay(6000);
   initSystem();
   ledsInit();
   String msg = "==========================\n";
   msg += "Sistema iniciado\n";
   msg += "==========================\n";
   DBG(msg.c_str());
   DBG("%s", buildSystemSummary().c_str());
   DBG("%s", buildStatus().c_str());
   DBG("%s", buildLog(10).c_str());
   DBG("%s", buildStatistics(5).c_str());

   // Somente para apagar todo o histórico:
   // resetState();
}

void loop() {

   ledsBeginCycle();
   int16_t rssi;
   LinkStatus status[NUM_LINKS];
   TelegramUpdate upd;
   bool telegramChecked = false;

   for (uint8_t i = 0; i < NUM_LINKS; i++) {
      ledsUpdate();
      DBG("\n=== %s ===\n", LINKS[i].nome);

      uint8_t retries =
          (gState.links[i].status == LINK_ONLINE) ? LINK_TEST_RETRIES : 1;
      status[i] = testConnection(LINKS[i].ssid, LINKS[i].senha, &rssi, retries);

      processLink(&gState.links[i], i, status[i], rssi);
      checkNotificationPolicy(); // Verifica se existe um link que caiu durante
                                 // o horário de silêncio e gera a notificação
                                 // quando sair dele

      // checkSummary();

      if (hasPendingNotifications())
         sendPendingNotifications();

      DBG("Vai tratar comandos\n");
      uint32_t t = millis();
      if (!telegramChecked && status[i] == LINK_ONLINE) {
         // DBG("telegramUpdateId = %lu\n", gState.telegramUpdateId);
         // DBG("Consultando Telegram...\n");
         for (uint8_t i = 0; i < MAX_UPDATES_PER_CYCLE; i++) {
            if (!telegramGetUpdates(&upd)) {
               break;
            }
            telegramChecked = true;
            DBG("getUpdates: %lu ms\n", millis() - t);
            DBG("update recebido = %lu\n", upd.updateId);

            t = millis();

            gState.telegramUpdateId = upd.updateId;
            saveState(&gState);
            DBG("saveState: %lu ms\n", millis() - t);

            if (!isAuthorizedChat(upd.chatId)) {
               telegramSendMessage("⛔ Chat não autorizado.\nUse o MonitLinks");
               continue;
            }
            if (upd.text.isEmpty())
               continue;
            t = millis();

            String resposta = telegramProcessCommand(upd.text);
            DBG("processCommand: %lu ms\n", millis() - t);
            t = millis();
            if (!resposta.isEmpty())
               telegramSendMessage(resposta);
            break;
         }
      }
      DBG("sendMessage: %lu ms\n", millis() - t);
      DBG("Tratou comandos\n");

      disconnectWifi();
   }

   uint8_t online = 0;

   for (uint8_t i = 0; i < NUM_LINKS; i++)
      if (status[i] == LINK_ONLINE)
         online++;

   LedStatus ledStatus;
   if (online == NUM_LINKS)
      ledStatus = LED_ALL_UP;
   else if (online == 0)
      ledStatus = LED_ALL_DOWN;
   else
      ledStatus = LED_PARTIAL_DOWN;

   gState.cicloCount++;
   saveState(&gState);

   ledsEndCycle(ledStatus);

   delay(5000);
   goToSleep(); // Desabilitado enquanto não for necessário
}
